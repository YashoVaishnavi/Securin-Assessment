const express = require("express");
const router = express.Router();
const CVE = require("../models/CVE");

/**
 * @swagger
 * /cves:
 *   get:
 *     summary: Retrieve a list of CVEs with optional pagination, sorting, and filtering
 *     description: Fetch CVE data from the database with pagination, sorting, and optional filters like `cveId`, `year`, `score`, and `lastModifiedDays`.
 *     parameters:
 *       - in: query
 *         name: page
 *         description: The page number to retrieve
 *         required: false
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         description: The number of CVEs per page
 *         required: false
 *         schema:
 *           type: integer
 *           default: 10
 *       - in: query
 *         name: sortField
 *         description: The field by which to sort the results (e.g., `publishedDate`, `baseScoreV2`)
 *         required: false
 *         schema:
 *           type: string
 *           default: "publishedDate"
 *       - in: query
 *         name: sortOrder
 *         description: The sorting order (`asc` or `desc`)
 *         required: false
 *         schema:
 *           type: string
 *           default: "asc"
 *       - in: query
 *         name: cveId
 *         description: Filter by CVE ID (e.g., `CVE-1999-1234`)
 *         required: false
 *         schema:
 *           type: string
 *       - in: query
 *         name: year
 *         description: Filter by year (e.g., `2024`)
 *         required: false
 *         schema:
 *           type: string
 *       - in: query
 *         name: score
 *         description: Filter by CVSS score (either `baseScoreV2` or `baseScoreV3`)
 *         required: false
 *         schema:
 *           type: number
 *       - in: query
 *         name: lastModifiedDays
 *         description: Filter by CVEs modified in the last N days
 *         required: false
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: A list of CVEs matching the provided filters
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 cves:
 *                   type: array
 *                   items:
 *                   
 *                 totalRecords:
 *                   type: integer
 *                   description: The total number of CVEs available
 *                 totalPages:
 *                   type: integer
 *                   description: The total number of pages based on the limit
 *                 currentPage:
 *                   type: integer
 *                   description: The current page being viewed
 *       400:
 *         description: Invalid input parameters (e.g., invalid page number or sort field)
 *       500:
 *         description: Internal Server Error
 */

// Route to fetch paginated and sorted CVE data
router.get("/cves", async (req, res) => {
  try {
    const { page = 1, limit = 10, sortField = "publishedDate", sortOrder = "asc" } = req.query;

    
    const skip = (page - 1) * limit;

    // Fetch CVEs with pagination and sorting
    const cves = await CVE.find()
      .sort({ [sortField]: sortOrder === "asc" ? 1 : -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .exec();

    const totalRecords = await CVE.countDocuments(); 

    res.status(200).json({
      cves,
      totalRecords,
      totalPages: Math.ceil(totalRecords / limit),
      currentPage: parseInt(page),
    });
  } catch (err) {
    console.error("Error fetching CVE data:", err);
    res.status(500).json({ error: "Failed to fetch CVE data" });
  }
});

module.exports = router;
