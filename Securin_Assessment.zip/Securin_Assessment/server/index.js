const mongoose=require('mongoose');
const express=require('express');
const cron=require('node-cron');
const cors=require('cors');
const app=express();
const port =5000;

app.use(cors());

const cveRoute=require('./routes/cveRoute');
const CVEAPI = require('./utils/CVEAPI');
const CVE = require('./models/CVE');
const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

//! swagger setup

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'CVE Management API',
      version: '1.0.0',
      description: 'API for managing and retrieving CVE data',
    },
    servers: [
      {
        url: 'http://localhost:5000/api',
      },
    ],
  },
  components: {
    schemas: {
      CVE: {
        type: 'object',
        properties: {
          cveId: {
            type: 'string',
            description: 'The unique CVE ID (e.g., CVE-1999-1234)',
          },
          sourceIdentifier: {
            type: 'string',
            description: 'The source identifier for the CVE',
          },
          publishedDate: {
            type: 'string',
            format: 'date-time',
            description: 'The published date of the CVE',
          },
          lastModifiedDate: {
            type: 'string',
            format: 'date-time',
            description: 'The last modified date of the CVE',
          },
          vulnStatus: {
            type: 'string',
            description: 'The status of the CVE (e.g., Modified, Reserved)',
          },
          description: {
            type: 'string',
            description: 'A brief description of the CVE',
          },
          baseScore: {
            type: 'number',
            description: 'The base score of the CVE',
          },
          vectorString: {
            type: 'string',
            description: 'The vector string for CVSS',
          },
          criteria: {
            type: 'string',
            description: 'CPE criteria string',
          },
          matchCriteriaId: {
            type: 'string',
            description: 'The unique match criteria ID for the CPE match',
          },
            vulnerable: {
              type: 'boolean',
              description: 'Indicates if the CPE is vulnerable',
                },
              },
            },
    },
  },
  apis: ['./routes/cveRoute.js'], // Path to the API documentation file
};

const swaggerSpec = swaggerJsdoc(options);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));



CVEAPI();

//!mongoDB connection
mongoose.connect('mongodb://localhost:27017/CVELIST').then(()=>{
    app.listen(port,()=>{
        console.log(`Server is running on port ${port}`);
    })
}).catch((err)=>console.log(err));

app.use("/api",cveRoute);

//!fetching data from the database
app.get('/api/cves/:cveId', async (req, res) => {
  try {
    const cve = await CVE.findOne({ cveId: req.params.cveId });
    if (!cve) {
      return res.status(404).json({ message: 'CVE not found' });
    }
    res.json(cve);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});



//!cron job to sync data every 24 hours
cron.schedule("0 0 * * *", async () => {
    console.log("Starting CVE DATA sync...");
    try {
      await CVEAPI();
      console.log("Sync complete.");
    } catch (err) {
      console.error("Error during CVE DATA sync:", err.message);
    }
  });
  
















