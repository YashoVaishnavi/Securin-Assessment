const mongoose=require("mongoose")

const cveSchema=new mongoose.Schema({
    cveId:{
         type:String ,
         unique:true, 
        required:true
        },
    sourceIdentifier:String,
    description:String,
    publishedDate:Date,
    lastmodifiedDate:Date,
    vulnStatus:String,
    vectorString:String,
    baseScore:Number,
    accessVector:String,
    accessComplexity:String,
    authentication:String,
    confidentialityImpact:String,
    integrityImpact:String,
    availabilityImpact:String,
    baseSeverity:String,
    expliotabilityScore:Number,
    impactScore:Number,
    vulnerable:Boolean,
    criteria:String,
    matchCriteriaId:String
      
 
    
});

module.exports=mongoose.model('CVE',cveSchema);