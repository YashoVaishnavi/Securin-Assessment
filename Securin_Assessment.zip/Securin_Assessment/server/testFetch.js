const mongoose = require("mongoose");
const CVE = require("./models/CVE");

mongoose.connect("mongodb://localhost:27017/cve_database", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const testInsert = async () => {
  const testCVE = new CVE({
    cveId: "TEST-1234",
    description: "Test CVE Entry",
    publishedDate: new Date(),
    lastModifiedDate: new Date(),
  });

  await testCVE.save();
  console.log("Test document saved!");
  mongoose.connection.close();
};

testInsert().catch(console.error);
