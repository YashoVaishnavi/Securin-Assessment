const axios=require('axios');
const CVE=require('../models/CVE');

const NVD_CVE="https://services.nvd.nist.gov/rest/json/cves/2.0";


let skipCounter=0;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

//! get data from NVD and apply pagination
const CVEAPI=async()=>{
    let startIndex=skipCounter;
    const resultsPerPage=1000;
    let hasMoreData=true;

    while(hasMoreData){
        try{
            const response=await axios.get(NVD_CVE,{
                params:{
                    startIndex,
                    resultsPerPage,
                }
            });
            // console.log("Api Response",response.data);
            const cveItems=response.data.vulnerabilities;
            // console.log("cveItems",cveItems);
            if(cveItems.length > 0){
                await processData(cveItems);
                startIndex+=resultsPerPage;
                skipCounter+=cveItems.length;
                console.log(`Processed ${cveItems.length} records. Total processed: ${skipCounter}`);
                await sleep(3000);
            }else{
                hasMoreData=false;
            }
        }catch(err){
            console.error("Error while fetching data from NVD",err.message);
            hasMoreData=false;
        }

    }
};

//! process and store data
const processData = async (cveItems) => {
  for (const item of cveItems) {
    const cve = item.cve; 

   
    const metrics = cve.metrics?.cvssMetricV2?.[0]?.cvssData || {}; 
    const exploitabilityScore = cve.metrics?.cvssMetricV2?.[0]?.exploitabilityScore || null;
    const impactScore = cve.metrics?.cvssMetricV2?.[0]?.impactScore || null;
    const baseSeverity = cve.metrics?.cvssMetricV2?.[0]?.baseSeverity || "Unknown"
    const authentication = metrics.authentication || "N/A";
    const configuration = cve.configurations?.[0]?.nodes?.[0]?.cpeMatch?.[0] || {};  // Safely 
    // Flattening the CVE data
    const cveData = {
      cveId: cve.id,  
      sourceIdentifier: cve.sourceIdentifier,
      publishedDate: cve.published,
      lastmodifiedDate: cve.lastModified,
      vulnStatus: cve.vulnStatus || "Unknown",
      description: cve.descriptions?.[0]?.value || "None", 

      // CVSS Metrics (flattening nested fields)
      vectorString: metrics.vectorString || "N/A",
      baseScore: metrics.baseScore || null,
      baseSeverity: baseSeverity||"N/A",
      accessVector: metrics.accessVector || "N/A",
      accessComplexity: metrics.accessComplexity || "N/A",
      authentication: metrics.authentication || "N/A",
      confidentialityImpact: metrics.confidentialityImpact || "N/A",
      integrityImpact: metrics.integrityImpact || "N/A",
      availabilityImpact: metrics.availabilityImpact || "N/A",
      exploitabilityScore:exploitabilityScore,
      impactScore: impactScore,
      vulnerable: configuration.vulnerable || false,
      criteria: configuration.criteria || "N/A",
      matchCriteriaId: configuration.matchCriteriaId || "N/A",
    };

    try {
      // Save or update the CVE data to MongoDB
      await CVE.findOneAndUpdate({ cveId: cveData.cveId }, cveData, { upsert: true });
    //   console.log(`Stored CVE ID: ${cveData.cveId}`);
    } catch (err) {
      console.error(`Error while storing CVE ID ${cveData.cveId}:`, err.message);
    }
  }
};


module.exports=CVEAPI;